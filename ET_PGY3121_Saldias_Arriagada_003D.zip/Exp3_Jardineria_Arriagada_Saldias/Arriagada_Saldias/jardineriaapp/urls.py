from django.urls import path
from .views import *
urlpatterns=[ 
    path('', inicio, name="inicio"),
    path('2_SobreNosotros/', sobrenosotros, name="sobrenosotros"),
    path('3_Productos/', productos, name="productos"),
    path('carrito/', carrito, name="carrito"),
    path('5_DatosEnvio/', datosenvio, name="datosenvio"),
    path('6_Escribenos/', escribenos, name="escribenos"),
    path('7_Donaciones/', donaciones, name="donaciones"),
    path('8_Stock/', menustock, name="menustock"),
    path('9_Crear/', crear, name="crear"),
    path('eliminar/<id>', eliminar, name="eliminar"),
    path('modificar/<id>', modificar, name="modificar"),
    path('registro/',registrar, name="registro"),
    path('tienda/',tienda, name="tienda"),
    path('tienda/',tienda, name="tienda"),
    path('generarBoleta/', generarBoleta, name="generarBoleta"),
    path('agregar/<id>', agregar_producto, name="agregar"),
    path('eliminar/<id>', eliminar_producto, name="eliminar"),
    path('restar/<id>', restar_producto, name="restar"),
    path('limpiar/', limpiar_carrito, name="limpiar"),

]
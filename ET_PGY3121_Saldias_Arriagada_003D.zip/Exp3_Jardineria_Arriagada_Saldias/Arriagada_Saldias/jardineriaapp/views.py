from django.shortcuts import render, redirect
from .models import Producto, Boleta, detalle_boleta
from .forms import ProductoForm,RegistroUserFrom
from django.contrib.auth import authenticate,login
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from jardineriaapp.compra import Carrito

# Create your views here.
def inicio(request):
    return render(request, '1_Inicio.html')

def sobrenosotros(request):
    return render(request, '2_SobreNosotros.html')

def productos(request):
    return render(request, '3_Productos.html')

def carrito(request):
    return render(request, '4_Carrito.html')

def datosenvio(request):
    return render(request, '5_DatosEnvio.html')

def escribenos(request):
    return render(request, '6_Escribenos.html')

def donaciones(request):
    return render(request, '7_Donaciones.html')

    
#Apartir de este texto estara todo lo relacionado al login y a la base de datos

def menustock(request):
    productos = Producto.objects.raw('Select * from jardineriaapp_producto')
    datos = {'items':productos}
    return render(request, '8_Stock.html', datos)
@login_required
def crear(request):
    if request.method=='POST':
        productoform = ProductoForm(request.POST, request.FILES)
        if productoform.is_valid():
            productoform.save()     #similar al insert en función
            return redirect('menustock')
    else:
        productoform=ProductoForm()
    return render(request, '9_Crear.html',{'productoform': productoform})
@login_required
def eliminar(request, id):
    productoEliminado=Producto.objects.get(codigo=id)  #obtenemos un objeto por su pk
    productoEliminado.delete()
    return redirect('menustock')
@login_required
def modificar(request,id):
    producto = Producto.objects.get(codigo=id)         #obtenemos un objeto por su pk
    datos ={
        'form':ProductoForm(instance=producto)
    }
    if request.method=='POST':
        formulario = ProductoForm(data=request.POST, instance=producto)
        if formulario.is_valid:
            formulario.save()
            return redirect ('menustock')
    return render(request, '10_modificar.html', datos)

def registrar(request):
    data = {
        'form' : RegistroUserFrom()         #creamos un objeto de tipo forms para user
    }
    if request.method=="POST":
        formulario = RegistroUserFrom(data = request.POST)  
        if formulario.is_valid():
            formulario.save()
            user= authenticate(username=formulario.cleaned_data["username"],
                  password=formulario.cleaned_data["password1"])
            login(request,user)   
            return redirect('inicio')
        data["form"] = formulario
    return render(request, 'registration/registro.html', data)




def tienda(request):
    productos = Producto.objects.all()
    datos={
        'items':productos
    }
   
    return render(request, 'tienda.html',datos)


def agregar_producto(request,id):
    carrito_compra= Carrito(request)
    producto = Producto.objects.get(codigo=id)
    carrito_compra.agregar(producto=producto)
    return redirect('tienda')

def eliminar_producto(request, id):
    carrito_compra= Carrito(request)
    producto = Producto.objects.get(codigo=id)
    carrito_compra.eliminar(producto=producto)
    return redirect('tienda')

def restar_producto(request, id):
    carrito_compra= Carrito(request)
    producto = Producto.objects.get(codigo=id)
    carrito_compra.restar(producto=producto)
    return redirect('tienda')

def limpiar_carrito(request):
    carrito_compra= Carrito(request)
    carrito_compra.limpiar()
    return redirect('tienda')    


def generarBoleta(request):
    precio_total=0
    for key, value in request.session['carrito'].items():
        producto = Producto.objects.get(codigo=value['producto_id'])
        cantidad = value['cantidad']
        precio_total = precio_total + int(value['precio']) * int(value['cantidad'])
        
    
    producto.stock-= cantidad
    producto.save()
    boleta = Boleta(total = precio_total, estado="Procesando Pedido")
    boleta.save()
    productos = []
    for key, value in request.session['carrito'].items():
            producto = Producto.objects.get(codigo = value['producto_id'])
            cant = value['cantidad']
            subtotal = cant * int(value['precio'])
            detalle = detalle_boleta(id_boleta = boleta, id_producto = producto, cantidad = cant, subtotal = subtotal)
            detalle.save()
            productos.append(detalle)
    datos={
        'productos':productos,
        'fecha':boleta.fechaCompra,
        'total': boleta.total
    }
    request.session['boleta'] = boleta.id_boleta
    carrito = Carrito(request)
    carrito.limpiar()
    return render(request, 'detallecarrito.html',datos)
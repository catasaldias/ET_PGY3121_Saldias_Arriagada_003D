import datetime
from distutils.command.upload import upload
from django.db import models
from django.contrib.auth import get_user_model
from django.conf import settings
from django.core.validators import MinValueValidator
from django.contrib.auth.models import User

# Create your models here.
class Categoria(models.Model):
    idCategoria=models.IntegerField(primary_key=True, verbose_name="Id de Categoria")
    nombreCategoria=models.CharField(max_length=100, blank=True, verbose_name="Nombre de categoria")


    def __str__(self):
        return self.nombreCategoria

class Producto(models.Model):
    codigo=models.CharField(primary_key=True, max_length=4, verbose_name="Codigo")
    nombre=models.CharField(max_length=100, verbose_name="Nombre")
    precio=models.BigIntegerField( validators=[MinValueValidator(0)], verbose_name="Precio")
    stock=models.IntegerField(validators=[MinValueValidator(0)], verbose_name="Stock")
    imagen=models.ImageField(upload_to="imagenes", null=True, verbose_name="Imagen")
    categoria=models.ForeignKey(Categoria, on_delete=models.CASCADE, verbose_name="Categoria")

    def __str__(self):
        return self.codigo

class Boleta(models.Model):
    ESTADO_CHOICES = [
        ('PP', 'Procesando Pedido')
    ]
    id_boleta=models.AutoField(primary_key=True)
    total=models.BigIntegerField()
    fechaCompra=models.DateTimeField(blank=False, null=False, default = datetime.datetime.now)
    estado = models.CharField(max_length=2,choices=ESTADO_CHOICES, default='PP')
    
    
    
    usuario = models.ForeignKey(User, on_delete=models.CASCADE, related_name='boletas', default=1   )
   
    def __str__(self):
        return str(self.id_boleta)

class detalle_boleta(models.Model):
    
    id_boleta = models.ForeignKey('Boleta', blank=True, on_delete=models.CASCADE, related_name='detalles')
    id_detalle_boleta = models.AutoField(primary_key=True)
    id_producto = models.ForeignKey('Producto', on_delete=models.CASCADE)
    cantidad = models.IntegerField()
    subtotal = models.BigIntegerField()
    

    def __str__(self):
        return str(self.id_detalle_boleta)
    


#COMENTARIOS
#Para Catalina: 1.-El import de validators puesto y los datos nuevos que puse uno es para que el precio no fuera 0 y revisar cuantos objetos hay en stock
#2.- me entere muy tarde que podria confundirse con la pagina "productos" pero no son lo mismo. lo siento
#3.-El import MinValueValidator es para revisar que cosas como el precio y el stock no sean negativos
#4.-use codigo como primary key no se me ocurria otra cosa por que nombres era mala idea como primary key :p
#5.-este sera el resplado para el cambio de nombre
#6.- ¿se podra hacer ahora lo del hacer una como interfaz base y trabajar desde ahi?

